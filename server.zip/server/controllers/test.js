module.exports = async (ctx) => {
    ctx.state.data = {
        msg: '网络请求成功！！'
    }
}
